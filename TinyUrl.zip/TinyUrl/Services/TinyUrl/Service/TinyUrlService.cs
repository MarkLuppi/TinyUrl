﻿using System.Collections.Concurrent;
using Microsoft.EntityFrameworkCore;



using TinyUrlWorkbench.Services.Interfaces;
using System;
using System.Diagnostics;


namespace TinyUrlWorkbench.Services.TinyUrl.Service
{


    public class TinyUrlService : IService
    {
     

        public List<TinyUrlClient> GetClients()
        {
            using (var context = new TinyUrlContext())
            {
                var list = context.Clients
                    .Include(a => a.LongUrl)
                    .ToList();
                return list;
            }
        }

        public interface IDataRepository
        {
            public List<TinyUrlClient> GetLongUrls();
        }

        public Dictionary<char, Delegate> Procs { get; set; }

       
      
        public static string RandomString(int length)
        {
            Random random = new Random();
           
            const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
            return new string(Enumerable.Repeat(chars, length)
                .Select(s => s[random.Next(s.Length)]).ToArray());
        }
    }

    public class TinyUrlClient
    {
        public int Id { get; set; }
        public List<LongUrl> LongUrl { get; set; }
     
    }

    public class LongUrl
    {
        public int Id { get; set; }
        public string UrlResource { get; set; }

    }

   
}

