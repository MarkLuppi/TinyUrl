﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TinyUrlWorkbench.Services.TinyUrl.Service;

namespace TinyUrlWorkbench.Services.Interfaces
{
    public interface IClient
    {
        public CancellationTokenSource Cts { get; set; }
        public Channel.Channel Channel { get; set; }
        public TinyUrlService Service { get; set; }

        public Dictionary<char, Delegate> Procs { get; set; }
    }
}
