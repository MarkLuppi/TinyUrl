﻿
using TinyUrlWorkbench.Channel;
using ClientViewManager = TinyUrlWorkbench.Client.CommandLineHandler;
using Client = TinyUrlWorkbench.Client.AppClient;
using TinyUrlWorkbench.Services.TinyUrl.Service;
using System.Diagnostics;
using System.Runtime.InteropServices;



Console.WriteLine("Hello, TinyUrlWorkbench!");

    //create the mock channel and client side service for each remote service
    var channel = Channel.ForAddress("https://mocklocalhost:8001/tiny-url-server");
    var service = channel.CreateService<TinyUrlService>();

    var client = new Client(service, channel);

// Create a command line manager.  Decouple it from the client, since we want to substitute for Blazor later

// When you run this, the app enters a read loop.
// It has the following one-letter commands available:
//    x -  Cancel and exit
//    g -  get the long urls entered so far
//    a -  add a long url (you will be prompted for the url string)
//    d -  delete a long url
//    u -  add a custom short url (you will be prompted for the short url, and then its long url)
//    n -  add a generated short url (you will be prompted for the short url, and then its long url)
//    r -  remove a custom short url (you will be prompted for the short url, and then its long url)
//    l -  launch a short url (you will be prompted for the short url)
//    c -  get the "clicked" count for the short url (number of launches) 

var clientViewManager = new ClientViewManager().Create(client);

    //keep the manager running until exit
    clientViewManager.Wait();
     
    Console.WriteLine("Exiting...");
