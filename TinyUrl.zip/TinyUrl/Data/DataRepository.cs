﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TinyUrlWorkbench;
using static TinyUrlWorkbench.Services.TinyUrl.Service.TinyUrlService;
using TinyUrlWorkbench.Data;

using TinyUrlWorkbench.Services.TinyUrl.Service;

namespace TinyUrlWorkbench.Data
{

    public class ApiContext : DbContext
    {
        protected override void OnConfiguring
       (DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseInMemoryDatabase(databaseName: "TinyUrlDB");
        }
  
    }
}

public class DataRepository : IDataRepository
{
    public DataRepository()
    {
        using (var context = new TinyUrlWorkbench.Services.TinyUrl.Service.TinyUrlContext())
        {
            var clients = new List<TinyUrlClient>
                {
                new TinyUrlClient
                {
                     LongUrl =new List<LongUrl>() { new LongUrl() { UrlResource = "hi" } }

                },
                new TinyUrlClient
                {
                    LongUrl =new List<LongUrl>() { new LongUrl() { UrlResource = "hi2" } }

                } };
            context.Clients.AddRange(clients);
            context.SaveChanges();
        }
    }

    public List<TinyUrlClient> GetLongUrls()
    {
        using (var context = new TinyUrlWorkbench.Services.TinyUrl.Service.TinyUrlContext())
        {
            var list = context.Clients
                .Include(a => a.LongUrl)
                .ToList();
            return list;
        }
    }
}
