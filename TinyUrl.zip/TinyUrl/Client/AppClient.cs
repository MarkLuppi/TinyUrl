﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Channels;
using System.Threading.Tasks;
using TinyUrlWorkbench.Channel;
using TinyUrlWorkbench.Services.Interfaces;
using TinyUrlWorkbench.Services.TinyUrl.Service;

namespace TinyUrlWorkbench.Client
{
    public class AppClient : IClient
    {
        public CancellationTokenSource Cts { get; set; }
        public TinyUrlService Service { get; set; }

        public Channel.Channel Channel { get; set; }

        public Dictionary<char, Delegate> Procs { get; set; }

        public string HelpText { get; set; }

        void Initialize()
        {
            Procs = new Dictionary<char, Delegate>();
            Procs['x'] = () => { Console.Write("Exiting..."); System.Environment.Exit(1); };
            Procs['h'] = () => Console.WriteLine("Help: " + HelpText);
            Procs['g'] = () => { var line = Console.ReadLine(); Console.WriteLine("Read: " + line); };
            Procs['l'] = () =>
            {
                Console.Write("Enter the Url: ");
                var url = Console.ReadLine();
                OpenUrl(url);
            };

            HelpText = @"
             This application has the following one-letter commands available:
                x -  Cancel and exit
                g -  get the long urls entered so far
                a -  add a long url(you will be prompted for the url string)
                d -  delete a long url
                u -  add a custom short url(you will be prompted for the short url, and then its long url)
                n -  add a generated short url(you will be prompted for the short url, and then its long url)
                r -  remove a custom short url(you will be prompted for the short url, and then its long url)
                l -  launch a short url(you will be prompted for the short url)
                c -  get the 'clicked' count for the short url(number of launches) ";
        }

        public AppClient (TinyUrlService service, Channel.Channel channel)
        {        
            Initialize(new CancellationTokenSource());
            Service = service;
            Channel = channel;
         
        }





        public void Initialize(CancellationTokenSource token)
        {
            Cts = token;
            Initialize();
        }

        // Wait for the tasks to complete execution
        // Task.WaitAll(appClient);

        ServiceRequest GetResponse(BlockingCollection<ServiceRequest> bc)
        {
            ServiceRequest nextItem = null;
            while (true)
            {
              
                try
                {
                    if (bc.TryTake(out nextItem, 0, Cts.Token))
                    {
                        nextItem = bc.Take();
                        
                        Console.WriteLine(" Take:{0}", nextItem);
                    }
                }

                catch (OperationCanceledException)
                {
                    Console.WriteLine("Taking canceled.");
                    break;
                }

                // Slow down consumer just a little to cause
                // collection to fill up faster, and lead to "AddBlocked"
                Thread.Sleep(2000);
            }
            return nextItem;
       
        }

        public void OpenUrl(string url)
        {
            try
            {
                Process.Start(url);
            }
            catch
            {
                // hack because of this: https://github.com/dotnet/corefx/issues/10361
                if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
                {
                    url = url.Replace("&", "^&");
                    Process.Start(new ProcessStartInfo(url) { UseShellExecute = true });
                }
                else if (RuntimeInformation.IsOSPlatform(OSPlatform.Linux))
                {
                    Process.Start("xdg-open", url);
                }
                else if (RuntimeInformation.IsOSPlatform(OSPlatform.OSX))
                {
                    Process.Start("open", url);
                }
                else
                {
                    throw;
                }
            }
        }

    }
}

