﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Transactions;
using TinyUrlWorkbench.Services.Interfaces;

namespace TinyUrlWorkbench.Client
{
    public class CommandLineHandler
    {
        public Task Create(IClient client)
        {
            IService service = client.Service;
            Dictionary<char, Delegate> proc = client.Procs;     

            return Task.Run(() =>
            {
                while (true)
                {
                    var key = Console.ReadKey(true).KeyChar;             
                    
                    proc[key].DynamicInvoke();
                }
            });
        }

       
    }
}
